#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Batch job submitter for modelbuilder batch inference service
"""

__version__ = "0.1.0" 