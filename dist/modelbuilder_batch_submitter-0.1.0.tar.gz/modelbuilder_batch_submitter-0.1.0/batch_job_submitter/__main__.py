#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Main entry point for batch job submitter
"""

from batch_job_submitter.cli import main

if __name__ == "__main__":
    main() 